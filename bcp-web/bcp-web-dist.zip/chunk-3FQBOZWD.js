function o(r){return r.url.startsWith("/nd")?"/nd":""}function s(r,t){let n=t.startsWith("/")?t:`/${t}`,e=o(r);return e?`${e}${n}`:n}function u(r,t){return[s(r,t)]}export{s as a,u as b};

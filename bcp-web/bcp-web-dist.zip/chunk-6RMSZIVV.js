import{a}from"./chunk-VP3VYUQU.js";import"./chunk-F74IBTIO.js";export default a();
